Para ver el funcionamiento e idea original (python)---> https://www.youtube.com/watch?v=EzedMdx6QG4

Con este pequeño server se puede hacer llamadas de manera continua mediante internet, sin posibilidad de ser bloqueado.

El servicio es gracias a Twillio. https://www.twilio.com/

